create
    definer = aon2003@localhost procedure new_model(IN mod_name varchar(255), IN br_id int unsigned)
begin
insert into models (name, brand_id) values (mod_name, br_id);
update brands
set num_models = num_models + 1
where brands.id = br_id;
end;

