create definer = aon2003@localhost trigger num_models
    after insert
    on models
    for each row
begin
update brands
set num_models = num_models + 1
where brands.id = NEW.brand_id;
end;

