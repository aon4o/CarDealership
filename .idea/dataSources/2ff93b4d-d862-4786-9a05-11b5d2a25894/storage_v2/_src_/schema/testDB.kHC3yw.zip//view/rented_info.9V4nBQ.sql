create definer = aon2003@localhost view rented_info as
select `rc`.`id`          AS `id`,
       `rc`.`vehicle_id`  AS `vehicle_id`,
       `vi`.`model`       AS `model`,
       `vi`.`brand`       AS `brand`,
       `vi`.`color`       AS `color`,
       `vi`.`horsepower`  AS `horsepower`,
       `vi`.`reg_num`     AS `reg_num`,
       `rc`.`customer_id` AS `customer_id`,
       `c`.`first_name`   AS `first_name`,
       `c`.`last_name`    AS `last_name`,
       `rc`.`start`       AS `start`,
       `rc`.`stop`        AS `stop`
from ((`testDB`.`rented_cars` `rc` join `testDB`.`vehicles_info` `vi` on ((`rc`.`vehicle_id` = `vi`.`id`)))
         join `testDB`.`customers` `c` on ((`rc`.`customer_id` = `c`.`id`)));

