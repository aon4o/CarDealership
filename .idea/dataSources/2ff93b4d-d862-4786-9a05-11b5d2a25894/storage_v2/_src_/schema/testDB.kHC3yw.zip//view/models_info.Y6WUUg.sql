create definer = aon2003@localhost view models_info as
select `m`.`id` AS `id`, `m`.`name` AS `name`, `b`.`name` AS `brand`
from (`testDB`.`models` `m`
         join `testDB`.`brands` `b` on ((`m`.`brand_id` = `b`.`id`)));

