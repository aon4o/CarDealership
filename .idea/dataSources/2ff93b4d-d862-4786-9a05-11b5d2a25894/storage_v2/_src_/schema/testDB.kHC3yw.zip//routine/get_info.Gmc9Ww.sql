create
    definer = aon2003@localhost function get_info(veh_id int unsigned) returns varchar(255)
begin
DECLARE model_id INT(10) UNSIGNED;
DECLARE brand_id INT(10) UNSIGNED;
DECLARE model_name VARCHAR(255);
DECLARE brand_name VARCHAR(255);
set model_id = (select vehicles.model_id from vehicles where vehicles.id = veh_id);
set brand_id = (select models.brand_id from models where models.id = model_id);
set model_name = (select models.name from models where models.id = model_id);
set brand_name = (select brands.name from brands where brands.id = brand_id);
return concat('Brand = ',brand_name,', Model = ',model_name,'.');
end;

