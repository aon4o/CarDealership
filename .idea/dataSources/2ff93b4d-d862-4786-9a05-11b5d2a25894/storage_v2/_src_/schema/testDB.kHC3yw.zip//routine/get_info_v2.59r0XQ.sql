create
    definer = aon2003@localhost function get_info_v2(veh_id int unsigned) returns varchar(255)
begin
return (SELECT CONCAT('Brand = ', brands.name, ', Model  ', models.name, '.') FROM brands JOIN models ON models.brand_id = brands.id JOIN vehicles ON vehicles.model_id = models.id WHERE vehicles.id = veh_id LIMIT 1);
end;

