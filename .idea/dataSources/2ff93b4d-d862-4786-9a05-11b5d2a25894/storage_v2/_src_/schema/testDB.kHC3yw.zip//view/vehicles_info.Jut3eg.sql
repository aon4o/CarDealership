create definer = aon2003@localhost view vehicles_info as
select `v`.`id`         AS `id`,
       `m`.`name`       AS `model`,
       `b`.`name`       AS `brand`,
       `v`.`color`      AS `color`,
       `v`.`horsepower` AS `horsepower`,
       `v`.`reg_num`    AS `reg_num`
from ((`testDB`.`vehicles` `v` join `testDB`.`models` `m` on ((`v`.`model_id` = `m`.`id`)))
         join `testDB`.`brands` `b` on ((`m`.`brand_id` = `b`.`id`)))
order by `v`.`id`;

